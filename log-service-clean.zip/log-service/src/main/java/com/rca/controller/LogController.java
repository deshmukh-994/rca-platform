package com.rca.controller;

import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
public class LogController {

    private final KafkaTemplate<String, String> kafka;
    private final String topic;

    public LogController(KafkaTemplate<String, String> kafka) {
        this.kafka = kafka;
        String t = System.getenv("KAFKA_TOPIC");
        this.topic = (t == null || t.isEmpty()) ? "logs" : t;
    }

    @GetMapping("/health")
    public Map<String, String> health() {
        Map<String, String> m = new HashMap<>();
        m.put("status", "ok");
        return m;
    }

    @PostMapping("/ingest")
    public Map<String, Object> ingest(@RequestBody String body) {
        kafka.send(topic, body);
        Map<String, Object> m = new HashMap<>();
        m.put("queued", true);
        return m;
    }
}
