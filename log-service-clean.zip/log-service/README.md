# log-service (clean build)

This is a minimal, **known-good** Spring Boot 3 (Java 17) service that exposes:
- `GET /api/health` → `{ "status": "ok" }`
- `POST /api/ingest` (raw text body) → sends the line to Kafka topic `KAFKA_TOPIC` (default: `logs`)

## Build & Run (Docker)
```bash
docker build -t log-service:clean .
docker run --rm -p 8080:8080 -e SPRING_KAFKA_BOOTSTRAP_SERVERS=localhost:9092 log-service:clean
```

## Use with docker-compose (rca-platform)
Replace your `rca-platform/log-service` folder with this one and rebuild that service:
```bash
docker compose build --no-cache log-service
docker compose up log-service
```

## Local dev (no Docker)
```bash
./mvnw spring-boot:run
# or with system mvn:
mvn spring-boot:run
```
